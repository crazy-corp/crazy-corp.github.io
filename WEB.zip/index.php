<?php

if(isset($_POST["submit"]))
{
	$recipient="vibinoff@gmail.com";
		$subject=$_POST["subject"];
		
$sender=$_POST["name"];

$mail=$_POST["mail"];

$message=$_POST["message"];

$mailBody="Name:$sender
\nEmail:$mail
\n\n$message";
mail($recipient,$subject,$mailBody,"From: $sender<$mail>");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link
      href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900"
      rel="stylesheet"
    />

    <title>Vibin Dave D</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="shortcut icon" href="assets/images/favicon.ico" />

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css" />
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/owl.css" />
    <link rel="stylesheet" href="assets/css/lightbox.css" />
  </head>

  <body>
          <div id="loader-wrapper">
            <div id="loader"></div>
        </div>
    <div id="page-wraper">
      <!-- Sidebar Menu -->
      <div class="responsive-nav">
        <i class="fa fa-bars" id="menu-toggle"></i>
        <div id="menu" class="menu">
          <i class="fa fa-times" id="menu-close"></i>
          <div class="container">
            <div class="image">
              <a href="#"><img src="assets/images/vibin.jpg" alt="" /></a>
            </div>
            <div class="author-content">
              <h4>Vibin Dave D</h4>
              <span>Electric circuit enthusiast <br> Web design and developer <br> Graphic Designer <br> Entrepreneurship</span>
            </div>
            <nav class="main-nav" role="navigation">
              <ul class="main-menu">
                <li><a href="#section1">About Me</a></li>
                <li><a href="#section2">What I’m good at</a></li>
                <li><a href="#section3">My Works</a></li>
                <li><a href="#section4">Contact Me</a></li>
              </ul>
            </nav>
            <div class="social-network">
              <ul class="soial-icons">
                <li>
                  <a href="https://www.facebook.com/crazycorp01/"
                    ><i class="fa fa-facebook"></i
                  ></a>
                </li>
                <li>
                  <a href="https://www.instagram.com/_vibin_dave_/"><i class="fa fa-instagram"></i></a>
                </li>
                <li>
                  <a href="https://www.linkedin.com/in/vibin-dave-d-717099190"><i class="fa fa-linkedin"></i></a>
                </li>
                <li>
                  <a href="https://www.youtube.com/channel/UCK6ZQqAapbSv5TGCPHshsVw/featured?view_as=subscriber"><i class="fa fa-youtube"></i></a>
                </li>
              </ul>
            </div>
            <div class="copyright-text">
              <p>Copyright 2020 Vibin Dave D</p>
            </div>
          </div>
        </div>
      </div>

      <section class="section about-me" data-section="section1">
        <div class="container">
          <div class="section-heading">
            <h2>Hi there!</h2>
            <div class="line-dec"></div>
            <span
              >This is just a overview of my profile.Hope you will enjoy!</span
            >
          </div>
          <div class="left-image-post">
            <div class="row">
              <div class="col-md-6">
                <div class="left-text">
					<div id="box">
                  <h4>My Resume</h4>
                  <p>
						You can find my resume here! If you wish to know about my academic status and all, Give a peek inside!. 
                  </p>
                  <div class="white-button">
                    <a href="https://drive.google.com/file/d/1qU25eujPKjgw6jctncA_VW8YM1SElvoq/view?usp=sharing">My CV</a>
					</div>
                  </div>
                </div>
              </div>
			   <div class="col-md-6">
                <div class="right-text">
                  <h4>Find me</h4>
                  <p>
                    Feel free to contact me in any need, I am always looking for new oppurtunities to build my profile!.You can find links to my various social networks in menu. I am always looking forward to make my network more stronger!
                  </p>
                  <div class="white-button">
                    <a href="#section4">LinkedIn</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section my-services" data-section="section2">
        <div class="container">
          <div class="section-heading">
            <h2>What I’m good at?</h2>
            <div class="line-dec"></div>
            <span
              >Here is the list of my skills, The best which makes me feel worthy !</span
            >
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="service-item">
				<i class="fa fa-pencil-square-o"></i>
                <h4>Graphic Design &amp; Video Editing</h4>
                <p>
                  I have pretty good knowledge in Adobe CC softwares like Photoshop,Premeire Pro,After effects,Lightroom classic and also intermediate knowledge in adobe Indesign,Filmora 9,Hitfilm Express and cyberlink Powerdirector.
                </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="service-item">
               <i class="fa fa-globe"></i>
                <h4>Web Design &amp; Development</h4>
                <p>
                  I have worked on various website projects for my college. I am too confident in frontend and intermediate level in backend. I can handle wordpress,google sites also.You can check out my works below.
                </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="service-item">
                <i class="fa fa-bolt" aria-hidden="true"></i>
                <h4>Electrical circuits &amp; IoT</h4>
                <p>
                  I have knowledge in softwares like Matlab, Pspics and i have past work experience on DJI F450 Drone. I am good in Aurdino and beginner in Raspberry Pi.I always had equal intrest towards Electronics and Computer Science.
                </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="service-item">
                <i class="fa fa-btc" aria-hidden="true"></i>
                <h4>Entrepreneurship</h4>
                <p>
                 It's not always about money, isn't it. I have plans to come up with a new startup , Currently i have work experience helping my dad to run a small scale industry of interlocks. In future maybe i'll extend my knowledge to expand my empire. 
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section my-work" data-section="section3">
        <div class="container">
          <div class="section-heading">
            <h2>My Works</h2>
            <div class="line-dec"></div>
            <span
              >A peek into my past works!</span
            >
          </div>
          <div class="row">
            <div class="isotope-wrapper">
              <form class="isotope-toolbar">
                <label
                  ><input
                    type="radio"
                    data-type="*"
                    checked=""
                    name="isotope-filter"
                  />
                  <span>all</span></label
                >
                <label
                  ><input
                    type="radio"
                    data-type="people"
                    name="isotope-filter"
                  />
                  <span>Web</span></label
                >
                <label
                  ><input
                    type="radio"
                    data-type="nature"
                    name="isotope-filter"
                  />
                  <span>Design</span></label
                >
                <label
                  ><input
                    type="radio"
                    data-type="animals"
                    name="isotope-filter"
                  />
                  <span>Projects</span></label
                >
              </form>
              <div class="isotope-box">
                <div class="isotope-item" data-type="nature">
                  <figure class="snip1321">
                    <img
                      src="assets/images/insta.png"
                      alt="sq-sample26"
                    />
                    <figcaption>
                      <a
                        href="https://www.instagram.com/explore/tags/crazycorpdesign/"
                        data-title="Caption"
                        ><i class="fa fa-instagram"></i
                      ></a>
                      <h4>Instagram wall</h4>
                      <span>Find all my past design works here!</span>
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="people">
                  <figure class="snip1321">
                    <img
                      src="assets/images/wordpress.png"
                      alt="sq-sample26"
                    />
                    <figcaption>
                      <a
                        href="https://en.gravatar.com/vibinoff"
                        ><i class="fa fa-wordpress"></i
                      ></a>
                      <h4>Gravatar &amp; Wordpress</h4>
                      <span>My Wordpress sites</span>
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="animals">
                  <figure class="snip1321">
                    <img
                      src="assets/images/drone.png"
                      alt="sq-sample26"
                    />
                    <figcaption>
                      <a
                        href="https://www.youtube.com/watch?v=x7OnMFTvV_U"
                        ><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                      <h4>DJI F450 Drone</h4>
                      <span>Check out my video of drone making!</span>
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="people">
                  <figure class="snip1321">
                    <img
                      src="assets/images/gc.png"
                      alt="sq-sample26"
                    />
                    <figcaption>
                      <a
                        href="http://gc-nitap.000webhostapp.com/"
                        ><i class="fa fa-globe"></i
                      ></a>
                      <h4>Website project</h4>
                      <span>I was part of development of this one</span>
                    </figcaption>
                  </figure>
                </div>

                <div class="isotope-item" data-type="nature">
                  <figure class="snip1321">
                    <img
                      src="assets/images/channel.png"
                      alt="sq-sample26"
                    />
                   <figcaption>
                      <a
                        href="https://www.youtube.com/channel/UCK6ZQqAapbSv5TGCPHshsVw/featured?view_as=subscriber"
                        ><i class="fa fa-youtube"></i
                      ></a>
                      <h4>Youtube channel</h4>
                      <span>Check out videos by me!</span>
                    </figcaption>
                  </figure>
                </div>

             <!--  <div class="isotope-item" data-type="animals">
                  <figure class="snip1321">
                    <img
                      src="assets/images/portfolio-06.jpg"
                      alt="sq-sample26"
                    />
                    <figcaption>
                      <a
                        href="https://www.youtube.com/watch?v=x7OnMFTvV_U"
                        ><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                      <h4>DJI F450 Drone</h4>
                      <span>Check out my video of drone making!</span>
                    </figcaption>
                  </figure>
                </div>-->
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section contact-me" data-section="section4">
        <div class="container">
          <div class="section-heading">
            <h2>Contact Me</h2>
            <div class="line-dec"></div>
            <span
              >Please provide your email so that i can contact you easily!</span
            >
          </div>
          <div class="row">
            <div class="right-content">
              <div class="container">
                <form id="contact" action="index.php" method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <fieldset>
                        <input
                          name="name"
                          type="text"
                          class="form-control"
                          id="name"
                          placeholder="Your name..."
                          required=""
                        />
                      </fieldset>
                    </div>
                    <div class="col-md-6">
                      <fieldset>
                        <input
                          name="mail"
                          type="text"
                          class="form-control"
                          id="email"
                          placeholder="Your email..."
                          required=""
                        />
                      </fieldset>
                    </div>
                    <div class="col-md-12">
                      <fieldset>
                        <input
                          name="subject"
                          type="text"
                          class="form-control"
                          id="subject"
                          placeholder="Subject..."
                          required=""
                        />
                      </fieldset>
                    </div>
                    <div class="col-md-12">
                      <fieldset>
                        <textarea
                          name="message"
                          rows="6"
                          class="form-control"
                          id="message"
                          placeholder="Your message..."
                          required=""
                        ></textarea>
                      </fieldset>
                    </div>
                    <div class="col-md-12">
                      <fieldset>
                        <button type="submit" name="submit" id="form-submit" class="button">
                          Send Message
                        </button>
                      </fieldset>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

    <!-- Scripts -->
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/isotope.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <script src="assets/js/custom.js"></script>
    <script>
      //according to loftblog tut
      $(".main-menu li:first").addClass("active");

      var showSection = function showSection(section, isAnimate) {
        var direction = section.replace(/#/, ""),
          reqSection = $(".section").filter(
            '[data-section="' + direction + '"]'
          ),
          reqSectionPos = reqSection.offset().top - 0;

        if (isAnimate) {
          $("body, html").animate(
            {
              scrollTop: reqSectionPos
            },
            800
          );
        } else {
          $("body, html").scrollTop(reqSectionPos);
        }
      };

      var checkSection = function checkSection() {
        $(".section").each(function() {
          var $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
          if (topEdge < wScroll && bottomEdge > wScroll) {
            var currentId = $this.data("section"),
              reqLink = $("a").filter("[href*=\\#" + currentId + "]");
            reqLink
              .closest("li")
              .addClass("active")
              .siblings()
              .removeClass("active");
          }
        });
      };

      $(".main-menu").on("click", "a", function(e) {
        e.preventDefault();
        showSection($(this).attr("href"), true);
      });

      $(window).scroll(function() {
        checkSection();
      });
    </script>
	        <script type="text/javascript">
            //<![CDATA[
            $(window).load(function() { // makes sure the whole site is loaded
                $('#loader').fadeOut(); // will first fade out the loading animation
                    $('#loader-wrapper').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
                $('body').delay(350).css({'overflow-y':'visible'});
            })
            //]]>
        </script>
  </body>
</html>
